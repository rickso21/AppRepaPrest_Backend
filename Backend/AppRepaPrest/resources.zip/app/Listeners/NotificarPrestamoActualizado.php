<?php

namespace App\Listeners;

use App\Events\PrestamoActualizado;
use App\Services\PushNotificationService;
use Illuminate\Support\Facades\Log;

class NotificarPrestamoActualizado
{
    public function __construct(
        protected PushNotificationService $push
    ) {}

    public function handle(PrestamoActualizado $event): void
    {
        try {
            $prestamo = $event->prestamo;

            // 🎯 El destinatario es el dueño del préstamo (el usuario)
            $usuarioDestino = $prestamo->usuario;

            if (!$usuarioDestino || empty($usuarioDestino->expo_push_token)) return;

            $title = 'Delivery Sobre Ruedas';
            $body = '';
            $screen = 'SolicitudPrestamo'; // Por defecto

            // Evaluamos el nuevo estado
            switch ($event->estadoNuevo) {
                case 2: // Aprobado
                    $body = "✅ ¡Buenas noticias! Tu préstamo por $" . number_format($prestamo->monto_solicitado, 0) . " ha sido APROBADO.";
                    $screen = 'PrestamoActivo';
                    break;
                case 4: // Pagado
                    $body = "🎉 ¡Felicidades! Has liquidado tu préstamo. Tu línea de crédito ha sido reactivada.";
                    $screen = 'PrestamoPagado'; // 👈 Cambiado para que el frontend lo maneje
                    break;
                case 5: // Rechazado
                    $body = "❌ Tu solicitud de préstamo ha sido rechazada. Motivo: " . ($prestamo->motivo_rechazo ?? 'No especificado');
                    $screen = 'PrestamoRechazado'; // 👈 Cambiado para que el frontend lo maneje
                    break;
                default:
                    return; // Si es otro estado, no notificamos
            }

            $this->push->sendToUser(
                user: $usuarioDestino,
                title: $title,
                body: $body,
                data: [
                    'screen' => $screen,
                    'prestamoId' => $prestamo->id,
                ]
            );

            Log::info('[push.prestamo] Estado actualizado notificado al usuario', [
                'prestamo_id' => $prestamo->id,
                'usuario_id' => $usuarioDestino->id,
                'nuevo_estado' => $event->estadoNuevo
            ]);

        } catch (\Throwable $e) {
            Log::error('[push.prestamo] Error actualizado: ' . $e->getMessage());
        }
    }
}
